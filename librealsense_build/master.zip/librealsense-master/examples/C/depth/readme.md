# rs-depth Sample

## Overview
This sample demonstrates how to use C API to stream depth data and prints a simple text-based representation of the depth image, by breaking it into 10x5 pixel regions and approximating the coverage of pixels within one meter.
